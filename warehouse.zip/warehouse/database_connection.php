<?php
$client_connection = mysqli_connect('localhost', 'root', '', 'client_storage');
$product_connection = mysqli_connect('localhost', 'root', '', 'product_storage');
$user_connection = mysqli_connect('localhost', 'root', '', 'user_storage');
$unv_product_connection = mysqli_connect('localhost', 'root', '', 'unv_products');
?>